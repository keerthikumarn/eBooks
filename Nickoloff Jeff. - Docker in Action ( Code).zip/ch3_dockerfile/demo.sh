#!/bin/sh
echo This image was built from a Dockerfile
