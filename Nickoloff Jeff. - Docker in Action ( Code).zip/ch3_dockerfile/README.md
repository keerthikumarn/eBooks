Build Instructions
==================
First clone the repo and change into the newly created directory. Then run:

    docker build -t dockerinaction/ch3_dockerfile .

After doing so, you will have built the image. To run the example run:

    docker run --rm dockerinaction/ch3_dockerfile 
