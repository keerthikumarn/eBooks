#!/bin/bash
figlet $@ | lolcat
