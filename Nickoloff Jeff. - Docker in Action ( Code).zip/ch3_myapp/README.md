docker build -t allingeek/ch3_ex_myapp:java6 ./j6/

docker build -t allingeek/ch3_ex_myapp:java7 ./j7/
