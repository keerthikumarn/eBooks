#!/bin/sh
cat /config/config.json
