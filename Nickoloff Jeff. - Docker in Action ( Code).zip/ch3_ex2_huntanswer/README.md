docker build -t allingeek/ch3_ex_huntanswer .

docker run -it --rm allingeek/ch3_ex_huntanswer
